#ifndef FUNC_H
#define FUNC_H
#include <stdio.h>
#include <stdlib.h>

void func1();
void func2();
void func3();
void func4();
void func5();
void func6();
void func7();
void func8();
void func9();
void func10();
void func11();
void func12();

#endif
